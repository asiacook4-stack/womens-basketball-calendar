# Women's Basketball 🏀 | 2026–27

Apple Calendar subscription for **UConn, South Carolina, UCLA, USC, LSU, Texas, Notre Dame, and Duke**.

## Setup

1. Upload this ZIP's **contents** to the repository root, preserving `.github/workflows/update-calendar.yml` and `scripts/update_calendar.py`.
2. In repository **Settings → Actions → General**, set **Workflow permissions** to **Read and write permissions**, then Save. If this setting is already managed by the repository, no change is needed.
3. In **Actions**, open **Update basketball calendar** and choose **Run workflow**. Wait for a green check mark. Confirm that `calendar.ics` appears in the repository root.
4. In **Settings → Pages**, choose **Deploy from a branch**, branch **main**, folder **/(root)**, and Save. Wait for the site to publish.
5. On your iPhone, open **Calendar → Calendars → Add Calendar → Add Subscription Calendar** and paste:

`https://asiacook4-stack.github.io/womens-basketball-calendar/calendar.ics`

6. Share the same subscription address with Benjamin.

## Updates

GitHub Actions checks the public ESPN women's college basketball scoreboard daily at 13:17 UTC. Apple Calendar refreshes subscribed feeds on its own schedule. The feed covers October 19, 2026 through April 8, 2027.

## Caveats

- This is an **unofficial**, best-effort schedule. ESPN's scoreboard data may omit games or change format; failed runs retain the previous file.
- Broadcasts and streaming links depend on the scoreboard listing. Links generally open streaming-service websites, not specific game playback.
- All selected-team games listed by the source are included once. Additional nationally important games *without* those teams are not currently included.
- Game duration is an estimate. Check official team and network listings before tipoff.
- The repository and calendar feed are public. Do not put personal information or passwords in them.
